export const colors = {
    text: '#206080',
    background: '#ddd',
    icon: '#444',
    white: '#fff',
    black: '#000',
    nope: '#E5566D',
    like: '#4CCC93',
    favorite: '#3CA3FF',
};
