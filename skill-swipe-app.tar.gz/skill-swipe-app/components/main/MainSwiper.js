import React, { useRef, useState } from 'react'
import { View, Text } from 'react-native'
import Swiper from 'react-native-deck-swiper'
import userProfiles from '../../data/userProfiles'
import Card from './Card'
import IconButton from './IconButton'
import OverlayLabel from './Overlaylabel'
//import mainStyles from 

const MainSwiper = (props) => {

  return (
    <View>
        <Text>
            YOO
        </Text>
    </View>
  )
}

export default MainSwiper